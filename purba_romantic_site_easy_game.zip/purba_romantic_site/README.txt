PURBA ROMANTIC WEBSITE — FREE GITHUB PAGES SETUP

1. Extract this ZIP.
2. Put your own photos inside the images folder, naming them photo1.jpg, photo2.jpg, photo3.jpg, or edit the PHOTOS array near the bottom of index.html to match your filenames. Do not upload private photos to a public repository without both people's consent.
3. Open index.html on your phone or computer. Press Start the Game; collect five hearts to unlock the letter. You can edit the letter text in index.html.
4. Create a PUBLIC GitHub repository, upload index.html and the images folder (preserve folder structure).
5. Go to repository Settings > Pages > Deploy from a branch > main / (root) > Save.
6. Open the published github.io URL after deployment. GitHub Pages has usage limits and requires the repository/hosting to remain available.
7. Keep a second backup of the originals and site ZIP in Google Drive or on your device.
No Cloudinary, no API keys, no monthly subscription needed. Game works offline in the HTML file. The images only show once the files are added.

EASY GAME UPDATE: Find 3 glowing hearts among 6 tiles. Wrong taps never reduce score.
